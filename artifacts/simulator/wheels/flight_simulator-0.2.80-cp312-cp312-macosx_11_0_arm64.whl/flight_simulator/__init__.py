from .flight_simulator import *

__doc__ = flight_simulator.__doc__
if hasattr(flight_simulator, "__all__"):
    __all__ = flight_simulator.__all__